package com.groupe.gestionDesStages.service.serviceImpl;

import com.groupe.gestionDesStages.dto.MessageDto;
import com.groupe.gestionDesStages.dto.NotificationDto;
import com.groupe.gestionDesStages.models.Candidature;
import com.groupe.gestionDesStages.models.Message;
import com.groupe.gestionDesStages.models.Utilisateur;
import com.groupe.gestionDesStages.repository.CandidatureRepository;
import com.groupe.gestionDesStages.repository.MessageRepository;
import com.groupe.gestionDesStages.repository.UtilisateurRepository;
import com.groupe.gestionDesStages.service.IMessageService;
import com.groupe.gestionDesStages.validator.ObjectValidator;
import com.groupe.gestionDesStages.websocket.WebSocketService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MessageServiceImpl implements IMessageService {

    private final MessageRepository messageRepository;
    private final CandidatureRepository candidatureRepository;
    private final UtilisateurRepository utilisateurRepository;
    private final ObjectValidator<MessageDto> validator;
    private final WebSocketService webSocketService;

    @Override
    @Transactional
    public MessageDto createMessage(MessageDto messageDto) {
        validator.validate(messageDto);

        Candidature candidature = candidatureRepository.findById(messageDto.getCandidatureId())
                .orElseThrow(() -> new EntityNotFoundException("Candidature introuvable avec l'id : " + messageDto.getCandidatureId()));

        Utilisateur sender = utilisateurRepository.findById(messageDto.getSenderId())
                .orElseThrow(() -> new EntityNotFoundException("Expéditeur introuvable avec l'id : " + messageDto.getSenderId()));

        Utilisateur receiver = utilisateurRepository.findById(messageDto.getReceiverId())
                .orElseThrow(() -> new EntityNotFoundException("Destinataire introuvable avec l'id : " + messageDto.getReceiverId()));

        Message message = MessageDto.toEntity(messageDto, candidature, sender, receiver);
        Message savedMessage = messageRepository.save(message);
        // Temps réel: notifier le destinataire du nouveau message
        MessageDto payload = MessageDto.fromEntity(savedMessage);
        try {
            webSocketService.sendMessageToUser(payload.getReceiverId(), payload);
        } catch (Exception ignored) {
            // On ignore les erreurs websocket pour ne pas impacter la transaction principale
        }

        // Optionnel: pousser aussi une notification légère en temps réel (sans persistance ici)
        try {
            NotificationDto notif = new NotificationDto();
            notif.setUtilisateurId(payload.getReceiverId());
            notif.setTitle("Nouveau message");
            notif.setMessage("Vous avez reçu un nouveau message");
            webSocketService.sendNotificationToUser(payload.getReceiverId(), notif);
        } catch (Exception ignored) {
        }

        return payload;
    }

    @Override
    public MessageDto findById(Long id) {
        return messageRepository.findById(id)
                .map(MessageDto::fromEntity)
                .orElseThrow(() -> new EntityNotFoundException("Message introuvable avec l'id : " + id));
    }

    @Override
    public List<MessageDto> findByCandidatureId(Long candidatureId) {
        return messageRepository.findByCandidatureId(candidatureId)
                .stream()
                .map(MessageDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<MessageDto> findBySenderIdOrReceiverId(Long userId) {
        return messageRepository.findBySenderIdOrReceiverId(userId, userId)
                .stream()
                .map(MessageDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        if (!messageRepository.existsById(id)) {
            throw new EntityNotFoundException("Message introuvable avec l'id : " + id);
        }
        messageRepository.deleteById(id);
    }
}
