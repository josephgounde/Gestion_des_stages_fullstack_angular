package com.groupe.gestionDesStages.controller;

import com.groupe.gestionDesStages.dto.RapportHebdomadaireDto;
import com.groupe.gestionDesStages.service.serviceImpl.RapportHebdomadaireServiceImpl;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/v1/rapports-hebdomadaires")
@RequiredArgsConstructor
public class RapportHebdomadaireController {

    private final RapportHebdomadaireServiceImpl rapportService;

    /**
     * Crée un nouveau rapport hebdomadaire.
     * Accessible uniquement par un utilisateur avec le rôle 'ETUDIANT'.
     */
    @PostMapping
    @PreAuthorize("hasAuthority('ETUDIANT')")
    public ResponseEntity<RapportHebdomadaireDto> createRapport(@RequestBody @Valid RapportHebdomadaireDto rapportHebdomadaireDto) {
        try {
            RapportHebdomadaireDto createdRapport = rapportService.createRapport(rapportHebdomadaireDto);
            return new ResponseEntity<>(createdRapport, HttpStatus.CREATED);
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), e);
        }
    }

    /**
     * Récupère un rapport par son ID.
     * L'étudiant, l'entreprise liée au stage ou un administrateur peuvent y accéder.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN') or hasAuthority('ETUDIANT')")
    public ResponseEntity<RapportHebdomadaireDto> findById(@PathVariable Long id) {
        try {
            RapportHebdomadaireDto rapport = rapportService.findById(id);
            return ResponseEntity.ok(rapport);
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }

    /**
     * Récupère tous les rapports hebdomadaires.
     * Endpoint restreint à l'administrateur pour des raisons de sécurité.
     */
    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<RapportHebdomadaireDto>> findAll() {
        List<RapportHebdomadaireDto> rapports = rapportService.findAll();
        return ResponseEntity.ok(rapports);
    }

    /**
     * Récupère les rapports d'un étudiant.
     * Accessible uniquement par l'étudiant lui-même ou par un administrateur.
     */
    @GetMapping("/etudiant/{etudiantId}")
    @PreAuthorize("hasAuthority('ADMIN') or hasAuthority('ETUDIANT')")
    public ResponseEntity<List<RapportHebdomadaireDto>> findByEtudiantId(@PathVariable Long etudiantId) {
        List<RapportHebdomadaireDto> rapports = rapportService.findByEtudiantId(etudiantId);
        return ResponseEntity.ok(rapports);
    }

    /**
     * Récupère les rapports liés à une offre de stage.
     * Accessible par l'entreprise qui propose le stage ou par un administrateur.
     */
    @GetMapping("/stage/{offreId}")
    @PreAuthorize("hasAuthority('ADMIN') or hasAuthority('ENTREPRISE')")
    public ResponseEntity<List<RapportHebdomadaireDto>> findByOffreId(@PathVariable Long offreId) {
        List<RapportHebdomadaireDto> rapports = rapportService.findByOffreId(offreId);
        return ResponseEntity.ok(rapports);
    }

    /**
     * Met à jour un rapport hebdomadaire.
     * Accessible uniquement par l'étudiant qui l'a créé
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ETUDIANT')")
    public ResponseEntity<RapportHebdomadaireDto> updateRapport(@PathVariable Long id, @RequestBody @Valid RapportHebdomadaireDto rapportHebdomadaireDto) {
        try {
            RapportHebdomadaireDto updatedRapport = rapportService.updateRapport(id, rapportHebdomadaireDto);
            return ResponseEntity.ok(updatedRapport);
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }

    /**
     * Supprime un rapport hebdomadaire.
     * Accessible uniquement par l'étudiant qui l'a créé, ou un administrateur.
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN') or hasAuthority('ETUDIANT')")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        try {
            rapportService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }
}
