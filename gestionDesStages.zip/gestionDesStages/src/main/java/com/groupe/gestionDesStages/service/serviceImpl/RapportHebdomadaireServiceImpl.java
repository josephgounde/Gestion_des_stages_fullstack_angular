package com.groupe.gestionDesStages.service.serviceImpl;

import com.groupe.gestionDesStages.dto.RapportHebdomadaireDto;
import com.groupe.gestionDesStages.models.Offre;
import com.groupe.gestionDesStages.models.RapportHebdomadaire;
import com.groupe.gestionDesStages.models.Utilisateur;
import com.groupe.gestionDesStages.repository.OffreRepository;
import com.groupe.gestionDesStages.repository.RapportHebdomadaireRepository;
import com.groupe.gestionDesStages.repository.UtilisateurRepository;
import com.groupe.gestionDesStages.service.IRapportHebdomadaireServic;
import com.groupe.gestionDesStages.validator.ObjectValidator;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RapportHebdomadaireServiceImpl implements IRapportHebdomadaireServic {

    private final RapportHebdomadaireRepository rapportHebdomadaireRepository;
    private final UtilisateurRepository utilisateurRepository;
    private final OffreRepository offreRepository;
    private final ObjectValidator<RapportHebdomadaireDto> validator;

    @Override
    @Transactional
    public RapportHebdomadaireDto createRapport(RapportHebdomadaireDto rapportHebdomadaireDto) {

        validator.validate(rapportHebdomadaireDto);

        Utilisateur etudiant = utilisateurRepository.findById(rapportHebdomadaireDto.getEtudiant().getId())
                .orElseThrow(() -> new EntityNotFoundException("Étudiant introuvable avec id : " + rapportHebdomadaireDto.getEtudiant().getId()));

        Offre stage = offreRepository.findById(rapportHebdomadaireDto.getStage().getId())
                .orElseThrow(() -> new EntityNotFoundException("Offre de stage introuvable avec id : " + rapportHebdomadaireDto.getStage().getId()));

        RapportHebdomadaire rapport = rapportHebdomadaireDto.toEntity(etudiant, stage);
        RapportHebdomadaire savedRapport = rapportHebdomadaireRepository.save(rapport);
        return RapportHebdomadaireDto.fromEntity(savedRapport);
    }

    @Override
    public RapportHebdomadaireDto findById(Long id) {
        return rapportHebdomadaireRepository.findById(id)
                .map(RapportHebdomadaireDto::fromEntity)
                .orElseThrow(() -> new EntityNotFoundException("Rapport hebdomadaire introuvable avec id : " + id));
    }

    @Override
    public List<RapportHebdomadaireDto> findAll() {
        return rapportHebdomadaireRepository.findAll()
                .stream()
                .map(RapportHebdomadaireDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<RapportHebdomadaireDto> findByEtudiantId(Long etudiantId) {
        return rapportHebdomadaireRepository.findByEtudiantId(etudiantId)
                .stream()
                .map(RapportHebdomadaireDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<RapportHebdomadaireDto> findByOffreId(Long offreId) {
        return rapportHebdomadaireRepository.findByStageId(offreId)
                .stream()
                .map(RapportHebdomadaireDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<RapportHebdomadaireDto> findRapportsByEtudiantIdSorted(Long etudiantId) {
        return rapportHebdomadaireRepository.findByEtudiantIdOrderBySemaineNumeroAsc(etudiantId)
                .stream()
                .map(RapportHebdomadaireDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<RapportHebdomadaireDto> findRapportsByOffreIdSorted(Long offreId) {
        return rapportHebdomadaireRepository.findByStageIdOrderBySemaineNumeroAsc(offreId)
                .stream()
                .map(RapportHebdomadaireDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<RapportHebdomadaireDto> findRapportsByEtudiantIdAndOffreIdSorted(Long etudiantId, Long offreId) {
        return rapportHebdomadaireRepository.findByEtudiantIdAndStageIdOrderBySemaineNumeroAsc(etudiantId, offreId)
                .stream()
                .map(RapportHebdomadaireDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public RapportHebdomadaireDto updateRapport(Long id, RapportHebdomadaireDto rapportHebdomadaireDto) {
        // Validation
        validator.validate(rapportHebdomadaireDto);

        RapportHebdomadaire existingRapport = rapportHebdomadaireRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Rapport hebdomadaire introuvable avec id : " + id));

        existingRapport.setSemaineNumero(rapportHebdomadaireDto.getSemaineNumero());
        existingRapport.setDateDebutSemaine(rapportHebdomadaireDto.getDateDebutSemaine());
        existingRapport.setDateFinSemaine(rapportHebdomadaireDto.getDateFinSemaine());
        existingRapport.setActivitesRealisees(rapportHebdomadaireDto.getActivitesRealisees());
        existingRapport.setCompetencesAcquises(rapportHebdomadaireDto.getCompetencesAcquises());
        existingRapport.setDifficultes(rapportHebdomadaireDto.getDifficultes());
        existingRapport.setObjectifsSemaineSuivante(rapportHebdomadaireDto.getObjectifsSemaineSuivante());
        existingRapport.setUpdatedAt(LocalDateTime.now());

        RapportHebdomadaire updatedRapport = rapportHebdomadaireRepository.save(existingRapport);
        return RapportHebdomadaireDto.fromEntity(updatedRapport);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        if (!rapportHebdomadaireRepository.existsById(id)) {
            throw new EntityNotFoundException("Rapport hebdomadaire introuvable avec id : " + id);
        }
        rapportHebdomadaireRepository.deleteById(id);
    }
}
