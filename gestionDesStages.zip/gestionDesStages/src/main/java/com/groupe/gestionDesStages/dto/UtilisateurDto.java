package com.groupe.gestionDesStages.dto;

import com.groupe.gestionDesStages.models.Utilisateur;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
public class UtilisateurDto {

    private Long id;
    private String email;
    private String motDePasse;
    private RoleDto role;
    private String photoProfil;


    public static UtilisateurDto fromEntity(Utilisateur utilisateur) {
        if (utilisateur == null) {
            return null;
        }

        return UtilisateurDto.builder()
                .id(utilisateur.getId())
                .email(utilisateur.getEmail())
                .motDePasse(utilisateur.getMotDePasse())
                .role(RoleDto.fromEntity(utilisateur.getRole()))
                .build();
    }
}
