package com.groupe.gestionDesStages.security;

import com.groupe.gestionDesStages.models.Role;
import com.groupe.gestionDesStages.models.Utilisateur;
import com.groupe.gestionDesStages.models.enums.ERole;
import com.groupe.gestionDesStages.repository.RoleRepository;
import com.groupe.gestionDesStages.repository.UtilisateurRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

@Configuration
@RequiredArgsConstructor
public class InitAdminConfig {

    private final UtilisateurRepository utilisateurRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Bean
    public CommandLineRunner initAdmin() {
        return args -> {
            final String defaultAdminEmail = "admin@example.com";
            final String defaultAdminPassword = "admin23";

            Optional<Utilisateur> existingUser = utilisateurRepository.findByEmail(defaultAdminEmail);

            if (existingUser.isPresent()) {
                Utilisateur admin = existingUser.get();
                if (admin.getMotDePasse() != null && !passwordEncoder.matches(defaultAdminPassword, admin.getMotDePasse())) {
                    admin.setMotDePasse(passwordEncoder.encode(defaultAdminPassword));
                    utilisateurRepository.save(admin);
                    System.out.println("Mise à jour du mot de passe de l'administrateur " + defaultAdminEmail + ".");
                } else {
                    System.out.println("L'administrateur " + defaultAdminEmail + " existe déjà et le mot de passe est le même. Aucune action nécessaire.");
                }
            } else {
                Role adminRole = roleRepository.findByName(ERole.ADMIN)
                        .orElseThrow(() -> new IllegalStateException("Le rôle ADMIN n'a pas été trouvé dans la base de données."));

                Utilisateur admin = Utilisateur.builder()
                        .email(defaultAdminEmail)
                        .motDePasse(passwordEncoder.encode(defaultAdminPassword))
                        .role(adminRole)
                        .build();

                utilisateurRepository.save(admin);
                System.out.println("Création de l'administrateur par défaut réussie: email=" + defaultAdminEmail + ", password=" + defaultAdminPassword);
            }
        };
    }
}
