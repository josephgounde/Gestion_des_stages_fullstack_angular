package com.groupe.gestionDesStages.service;


import com.groupe.gestionDesStages.dto.UtilisateurDto;
import com.groupe.gestionDesStages.dto.serviceDto.RegisterRequestDto;
import com.groupe.gestionDesStages.models.Utilisateur;

import java.util.List;

public interface UtilisateurService {

    Utilisateur registerUtilisateur(RegisterRequestDto request);

    UtilisateurDto findUserById(Long id);

    UtilisateurDto findUserByEmail(String email);

    List<UtilisateurDto> findAllUsers();

    Utilisateur updateUtilisateur(UtilisateurDto utilisateurDto);

    void deleteUtilisateur(Long id);

}