package com.groupe.gestionDesStages.service;

import com.groupe.gestionDesStages.dto.RapportHebdomadaireDto;

import java.util.List;

public interface IRapportHebdomadaireServic {
    RapportHebdomadaireDto createRapport(RapportHebdomadaireDto rapportHebdomadaireDto);
    RapportHebdomadaireDto findById(Long id);
    List<RapportHebdomadaireDto> findAll();

    List<RapportHebdomadaireDto> findByEtudiantId(Long etudiantId);
    List<RapportHebdomadaireDto> findByOffreId(Long offreId);

    List<RapportHebdomadaireDto> findRapportsByEtudiantIdSorted(Long etudiantId);
    List<RapportHebdomadaireDto> findRapportsByOffreIdSorted(Long offreId);
    List<RapportHebdomadaireDto> findRapportsByEtudiantIdAndOffreIdSorted(Long etudiantId, Long offreId);

    RapportHebdomadaireDto updateRapport(Long id, RapportHebdomadaireDto rapportHebdomadaireDto);
    void deleteById(Long id);

}
