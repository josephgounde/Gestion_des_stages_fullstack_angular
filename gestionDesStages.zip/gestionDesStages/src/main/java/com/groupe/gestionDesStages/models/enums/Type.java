package com.groupe.gestionDesStages.models.enums;

public enum Type {
    APPLICATION, CONVENTION, MESSAGE, SYSTEM
}
