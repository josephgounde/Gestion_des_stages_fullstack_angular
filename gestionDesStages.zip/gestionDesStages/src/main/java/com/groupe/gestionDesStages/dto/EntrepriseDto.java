package com.groupe.gestionDesStages.dto;

import com.groupe.gestionDesStages.models.Entreprise;
import com.groupe.gestionDesStages.models.Role;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
public class EntrepriseDto extends UtilisateurDto {

    private String nom;
    private String siret;
    private String secteur;
    private String logoUrl;


    public static EntrepriseDto fromEntity(Entreprise entreprise) {
        if (entreprise == null) {
            return null;
        }
        return EntrepriseDto.builder()
                .id(entreprise.getId())
                .email(entreprise.getEmail())
                .motDePasse(entreprise.getMotDePasse())
                .role(RoleDto.fromEntity(entreprise.getRole()))
                .nom(entreprise.getNom())
                .siret(entreprise.getSiret())
                .secteur(entreprise.getSecteur())
                .logoUrl(entreprise.getLogoUrl())
                .photoProfil(entreprise.getPhotoProfil())
                .build();
    }


    public Entreprise toEntity(Role role) {
        if (this == null) {
            return null;
        }
        Entreprise entreprise = Entreprise.builder()
                .id(this.getId())
                .email(this.getEmail())
                .motDePasse(this.getMotDePasse())
                .role(role)
                .nom(this.nom)
                .siret(this.siret)
                .secteur(this.secteur)
                .logoUrl(this.logoUrl)
                .photoProfil(this.getPhotoProfil())
                .build();
        return entreprise;
    }
}
