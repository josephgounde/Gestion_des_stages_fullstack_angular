package com.groupe.gestionDesStages.dto;

import com.groupe.gestionDesStages.models.Offre;
import com.groupe.gestionDesStages.models.RapportHebdomadaire;
import com.groupe.gestionDesStages.models.Utilisateur;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RapportHebdomadaireDto {
    private Long id;
    private UtilisateurDto etudiant;
    private OffreDto stage;
    private Integer semaineNumero;
    private LocalDate dateDebutSemaine;
    private LocalDate dateFinSemaine;
    private String activitesRealisees;
    private String competencesAcquises;
    private String difficultes;
    private String objectifsSemaineSuivante;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;


    public static RapportHebdomadaireDto fromEntity(RapportHebdomadaire rapport) {
        if (rapport == null) {
            return null;
        }

        return RapportHebdomadaireDto.builder()
                .id(rapport.getId())
                .etudiant(rapport.getEtudiant() != null ? UtilisateurDto.fromEntity(rapport.getEtudiant()) : null)
                .stage(rapport.getStage() != null ? OffreDto.fromEntity(rapport.getStage()) : null)
                .semaineNumero(rapport.getSemaineNumero())
                .dateDebutSemaine(rapport.getDateDebutSemaine())
                .dateFinSemaine(rapport.getDateFinSemaine())
                .activitesRealisees(rapport.getActivitesRealisees())
                .competencesAcquises(rapport.getCompetencesAcquises())
                .difficultes(rapport.getDifficultes())
                .objectifsSemaineSuivante(rapport.getObjectifsSemaineSuivante())
                .createdAt(rapport.getCreatedAt())
                .updatedAt(rapport.getUpdatedAt())
                .build();
    }


    public RapportHebdomadaire toEntity(Utilisateur etudiant, Offre stage) {
        if (this == null) {
            return null;
        }

        return RapportHebdomadaire.builder()
                .id(this.id)
                .etudiant(etudiant)
                .stage(stage)
                .semaineNumero(this.semaineNumero)
                .dateDebutSemaine(this.dateDebutSemaine)
                .dateFinSemaine(this.dateFinSemaine)
                .activitesRealisees(this.activitesRealisees)
                .competencesAcquises(this.competencesAcquises)
                .difficultes(this.difficultes)
                .objectifsSemaineSuivante(this.objectifsSemaineSuivante)
                .createdAt(this.createdAt != null ? this.createdAt : LocalDateTime.now())
                .updatedAt(this.updatedAt)
                .build();
    }
}
