package com.groupe.gestionDesStages.models.enums;

public enum StatutCandidature {
    NOUVELLE,
    EN_ATTENTE,
    ACCEPTEE,
    REFUSEE
}
