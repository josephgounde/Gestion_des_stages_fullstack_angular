package com.groupe.gestionDesStages;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDesStagesApplication {
	public static void main(String[] args) {

		SpringApplication.run(GestionDesStagesApplication.class, args);
	}

}
