package com.groupe.gestionDesStages.models.enums;

public enum ERole {
    ETUDIANT,
    ENTREPRISE,
    ENSEIGNANT,
    ADMIN
}