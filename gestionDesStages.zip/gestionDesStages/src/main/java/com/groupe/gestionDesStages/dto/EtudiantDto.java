package com.groupe.gestionDesStages.dto;

import com.groupe.gestionDesStages.models.Etudiant;
import com.groupe.gestionDesStages.models.Role;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
public class EtudiantDto extends UtilisateurDto {

    private String nom;
    private String prenom;
    private String matricule;
    private String filiere;
    private String cvFile;

    // Convertir une entité vers DTO
    public static EtudiantDto fromEntity(Etudiant etudiant) {
        if (etudiant == null) {
            return null;
        }
        return EtudiantDto.builder()
                .id(etudiant.getId())
                .email(etudiant.getEmail())
                .motDePasse(etudiant.getMotDePasse())
                .role(RoleDto.fromEntity(etudiant.getRole()))
                .photoProfil(etudiant.getPhotoProfil())
                .nom(etudiant.getNom())
                .prenom(etudiant.getPrenom())
                .matricule(etudiant.getMatricule())
                .filiere(etudiant.getFiliere())
                .cvFile(etudiant.getCvFile())
                .build();
    }

    // Convertir un DTO vers entité
    public Etudiant toEntity(Role role) {
        return Etudiant.builder()
                .id(this.getId())
                .email(this.getEmail())
                .motDePasse(this.getMotDePasse())
                .role(role)
                .photoProfil(this.getPhotoProfil())
                .nom(this.getNom())
                .prenom(this.getPrenom())
                .matricule(this.getMatricule())
                .filiere(this.getFiliere())
                .cvFile(this.getCvFile())
                .build();
    }
}
