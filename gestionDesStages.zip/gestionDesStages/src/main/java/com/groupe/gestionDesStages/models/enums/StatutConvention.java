package com.groupe.gestionDesStages.models.enums;

public enum StatutConvention {
    EN_ATTENTE,
    VALIDEE_ENSEIGNANT,
    APPROUVEE_ADMIN,
    REFUSEE
}
