package com.groupe.gestionDesStages.repository;


import com.groupe.gestionDesStages.models.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin, Long> {}
