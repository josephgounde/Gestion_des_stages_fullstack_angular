package com.groupe.gestionDesStages.controller;

import com.groupe.gestionDesStages.dto.ConventionDto;
import com.groupe.gestionDesStages.service.serviceImpl.ConventionServiceImpl;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/v1/conventions")
@RequiredArgsConstructor
public class ConventionController {

    private final ConventionServiceImpl conventionService;


    @PostMapping
    public ResponseEntity<ConventionDto> createConvention(@RequestBody @Valid ConventionDto conventionDto) {
        try {
            ConventionDto createdConvention = conventionService.createConvention(conventionDto);
            return new ResponseEntity<>(createdConvention, HttpStatus.CREATED);
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }


    @GetMapping("/{id}")
    public ResponseEntity<ConventionDto> findById(@PathVariable Long id) {
        try {
            ConventionDto convention = conventionService.findById(id);
            return ResponseEntity.ok(convention);
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }


    @GetMapping("/all")
    public ResponseEntity<List<ConventionDto>> findAll() {
        List<ConventionDto> conventions = conventionService.findAll();
        return ResponseEntity.ok(conventions);
    }


    @PutMapping("/{id}")
    public ResponseEntity<ConventionDto> updateConvention(@PathVariable Long id, @RequestBody @Valid ConventionDto conventionDto) {
        try {
            ConventionDto updatedConvention = conventionService.updateConvention(id, conventionDto);
            return ResponseEntity.ok(updatedConvention);
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteConvention(@PathVariable Long id) {
        try {
            conventionService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (EntityNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }
}
