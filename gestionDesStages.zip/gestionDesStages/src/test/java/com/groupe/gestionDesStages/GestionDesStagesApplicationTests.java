package com.groupe.gestionDesStages;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDesStagesApplicationTests {

	@Test
	void contextLoads() {
	}

}
